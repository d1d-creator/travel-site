const { getKnex } = require('../../api/_lib/db');
const { requireAuth } = require('../_lib/auth');

module.exports = async (req, res) => {
  const user = requireAuth(req, res);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const knex = getKnex();
  await ensureBookings(knex);
  if (req.method === 'POST'){
    const { destination_id, name, email, guests, date } = req.body;
    if (!destination_id || !name || !email || !date) return res.status(400).json({ error: 'Missing' });
    const ids = await knex('bookings').insert({ destination_id, name, email, guests: guests||1, date }).returning('id');
    const id = Array.isArray(ids) ? ids[0] : ids;
    const booking = await knex('bookings').where({ id }).first();
    return res.status(201).json(booking);
  }
  if (req.method === 'GET'){
    const rows = await knex('bookings').select();
    return res.json(rows);
  }
  return res.status(405).json({ error: 'Method not allowed' });
};

async function ensureBookings(knex){
  const has = await knex.schema.hasTable('bookings');
  if (!has){
    await knex.schema.createTable('bookings', t=>{ t.increments('id').primary(); t.integer('destination_id'); t.string('name'); t.string('email'); t.integer('guests'); t.string('date'); t.timestamps(true,true); });
  }
}
