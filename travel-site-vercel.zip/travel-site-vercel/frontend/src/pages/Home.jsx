import React, { useEffect, useState } from 'react'
export default function Home(){
  const [d, setD] = useState([]);
  useEffect(()=>{ fetch('/api/destinations').then(r=>r.json()).then(setD) }, []);
  return (<div className="p-6"><h1 className="text-2xl font-bold mb-4">Wanderly</h1><div>{d.map(x=>(<div key={x.id}><h3>{x.name}</h3><p>{x.country} — ${x.price}</p></div>))}</div></div>)
}
